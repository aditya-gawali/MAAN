<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/flowbite@1.4.6/dist/flowbite.min.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- <script src="../path/to/flowbite/dist/flowbite.js"></script> -->
    <script src="https://unpkg.com/flowbite@1.4.6/dist/flowbite.js"></script>
    <title>Share Holder Report | MAAN BANK</title>
</head>

<body>

    <div class="text-center text-2xl font-bold tracking-tight text-blue-500 p-2">Report of Sahre Holder</div>
    <div class="p-1">
        <div class="p-4">
            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                SRN
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Share Holder Number
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Share Assign
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Share Assign Amount
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Share Assign From - TO
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // error_reporting(0);
                        include 'partials/dbconnect.php';
                        $srn = 0;
                        $SHNumber;
                        $fname;
                        $lname;
                        $name;
                        $dash = " - ";
                        $shareAssign;
                        $sharefrom = 0;
                        $shareto = 0;
                        $sharefromto;

                        $sql = "SELECT * FROM `share_holder`";
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            $srn++;
                            $SHNumber = $row["SHNumber"];
                            $fname = $row["first_name"];
                            $lname = $row["last_name"];
                            $name = $fname . " " . $lname;
                            $shareAssign = $row["ShareAssign"];
                            if ($SHNumber == 1) {
                                $sharefrom = 1;
                                $shareto = $shareAssign;
                            } else {
                                $sharefrom = $shareto + 1;
                                $shareto += $shareAssign;
                            }

                            $sharefromto = $sharefrom . " " . $dash . " " . $shareto;

                            echo '<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                                ' . $srn .  '
                            </th>
                            <td class="px-6 py-4">
                            ' . $SHNumber .  '
                            </td>
                            <td class="px-6 py-4">
                            ' . $name .  '
                            </td>
                            <td class="px-6 py-4">
                            ' . $shareAssign .  '
                            </td>
                            <td class="px-6 py-4">
                            ' . $shareAssign * 10 .  '
                            </td>
                            <td class="px-6 py-4">
                            ' . $sharefromto . '
                            </td>
                            
                        </tr>';
                        }
                        ?>

                    </tbody>
                </table>
            </div>

        </div>
    </div>

</body>

</html>